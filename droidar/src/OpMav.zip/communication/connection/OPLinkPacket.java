package communication.connection;

import java.io.Serializable;


public class OPLinkPacket implements Serializable {
	private static final long serialVersionUID = 2095947771227815314L;
	
	public static final int OPLINK_STX = 254;
	
	/**
	 * Message length. NOT counting STX, LENGTH, SEQ, SYSID, COMPID, MSGID, CRC1 and CRC2
	 */
	public int len;
	/**
	 * Message sequence
	 */
	public int seq;
	/**
	 * ID of the SENDING system. Allows to differentiate different MAVs on the
	 * same network.
	 */
	public int sysid;
	/**
	 * ID of the SENDING component. Allows to differentiate different components
	 * of the same system, e.g. the IMU and the autopilot.
	 */
	public int compid;
	/**
	 * ID of the message - the id defines what the payload means and how it
	 * should be correctly decoded.
	 */
	public int msgid;
	/**
	 * Data of the message, depends on the message id.
	 */
	public OPLinkPayload payload;
	/**
	 * ITU X.25/SAE AS-4 hash, excluding packet start sign, so bytes 1..(n+6)
	 * Note: The checksum also includes OPLINK_CRC_EXTRA (Number computed from
	 * message fields. Protects the packet from decoding a different version of
	 * the same packet but with different variables).
	 */
	
	public OPLinkPacket(){
		payload = new OPLinkPayload();
	}
	
	/**
	 * Check if the size of the Payload is equal to the "len" byte
	 */
	public boolean payloadIsFilled() {
		if (payload.size() >= OPLinkPayload.MAX_PAYLOAD_SIZE-1) {
			return true;
		}
		return (payload.size() == len);
	}
	

	/**
	 * Encode this packet for transmission. 
	 * 
	 * @return Array with bytes to be transmitted
	 */
	public byte[] encodePacket() {
		byte[] buffer = new byte[6 + len + 2];
		return buffer;
	}
	
	/**
	 * Unpack the data in this packet and return a OPLink message
	 * 
	 * @return OPLink message decoded from this packet
	 */
	public OPLinkMessage unpack() {
		return null;
	}

}
	
