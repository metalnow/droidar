package communication.connection;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Base for mavlink connection implementations.
 */
public abstract class OPLinkConnection {

	private static final String TAG = OPLinkConnection.class.getSimpleName();

	/*
	 * OpLink connection states
	 */
	public static final int OPLINK_DISCONNECTED = 0;
	public static final int OPLINK_CONNECTING = 1;
	public static final int OPLINK_CONNECTED = 2;

	/**
	 * Size of the buffer used to read messages from the mavlink connection.
	 */
	private static final int READ_BUFFER_SIZE = 4096;

	/**
	 * Maximum possible sequence number for a packet.
	 */
	private static final int MAX_PACKET_SEQUENCE = 255;

	/**
	 * Set of listeners subscribed to this mavlink connection. We're using a
	 * ConcurrentSkipListSet because the object will be accessed from multiple
	 * threads concurrently.
	 */
	private final ConcurrentHashMap<String, OPLinkConnectionListener> mListeners = new ConcurrentHashMap<String, OPLinkConnectionListener>();

	/**
	 * Queue the set of packets to log. A thread will be blocking on it until
	 * there's element(s) available for logging.
	 */
	private final LinkedBlockingQueue<OPLinkPacket> mPacketsToLog = new LinkedBlockingQueue<OPLinkPacket>();

	/**
	 * Queue the set of packets to send via the mavlink connection. A thread
	 * will be blocking on it until there's element(s) available to send.
	 */
	private final LinkedBlockingQueue<OPLinkPacket> mPacketsToSend = new LinkedBlockingQueue<OPLinkPacket>();

	private final AtomicInteger mConnectionStatus = new AtomicInteger(OPLINK_DISCONNECTED);

	/**
	 * Listen for incoming data on the mavlink connection.
	 */
	private final Runnable mConnectingTask = new Runnable() {

		@Override
		public void run() {
			Thread sendingThread = null;

			// Load the connection specific preferences
			loadPreferences();

			try {
				// Open the connection
				openConnection();
				mConnectionStatus.set(OPLINK_CONNECTED);
				reportConnect();

				// Launch the 'Sending', and 'Logging' threads
				sendingThread = new Thread(mSendingTask, "OpLinkConnection-Sending Thread");
				sendingThread.start();

				final byte[] readBuffer = new byte[READ_BUFFER_SIZE];

				while (mConnectionStatus.get() == OPLINK_CONNECTED) {
					int bufferSize = readDataBlock(readBuffer);
					//handleData(parser, bufferSize, readBuffer);
				}
			} catch (IOException e) {
				// Ignore errors while shutting down
				if (mConnectionStatus.get() != OPLINK_DISCONNECTED) {
					reportComError(e.getMessage());
				}
			} finally {

				if (sendingThread != null && sendingThread.isAlive()) {
					sendingThread.interrupt();
				}

				disconnect();
			}
		}

		/*
		private void handleData(Parser parser, int bufferSize, byte[] buffer) {
			if (bufferSize < 1) {
				return;
			}

			for (int i = 0; i < bufferSize; i++) {
				OPLinkPacket receivedPacket = parser.mavlink_parse_char(buffer[i] & 0x00ff);
				if (receivedPacket != null) {
					OPLinkMessage msg = receivedPacket.unpack();
					reportReceivedMessage(msg);
					queueToLog(receivedPacket);
				}
			}
		}
		*/
	};

	/**
	 * Blocks until there's packet(s) to send, then dispatch them.
	 */
	private final Runnable mSendingTask = new Runnable() {
		@Override
		public void run() {
			int msgSeqNumber = 0;

			try {
				while (mConnectionStatus.get() == OPLINK_CONNECTED) {
					final OPLinkPacket packet = mPacketsToSend.take();
					packet.seq = msgSeqNumber;
					byte[] buffer = packet.encodePacket();

					try {
						sendBuffer(buffer);
						queueToLog(packet);
					} catch (IOException e) {
						reportComError(e.getMessage());
					}

					msgSeqNumber = (msgSeqNumber + 1) % (MAX_PACKET_SEQUENCE + 1);
				}
			} catch (InterruptedException e) {
				
			} finally {
				disconnect();
			}
		}
	};

	private Thread mTaskThread;

	/**
	 * Establish a mavlink connection. If the connection is successful, it will
	 * be reported through the OpLinkConnectionListener interface.
	 */
	public void connect() {
		if (mConnectionStatus.compareAndSet(OPLINK_DISCONNECTED, OPLINK_CONNECTING)) {
			mTaskThread = new Thread(mConnectingTask, "OpLinkConnection-Connecting Thread");
			mTaskThread.start();
		}
	}

	/**
	 * Disconnect a oplink connection. If the operation is successful, it will
	 * be reported through the OpLinkConnectionListener interface.
	 */
	public void disconnect() {
		if (mConnectionStatus.get() == OPLINK_DISCONNECTED || mTaskThread == null) {
			return;
		}

		try {
			mConnectionStatus.set(OPLINK_DISCONNECTED);
			if (mTaskThread.isAlive() && !mTaskThread.isInterrupted()) {
				mTaskThread.interrupt();
			}

			closeConnection();
			reportDisconnect();
		} catch (IOException e) {			
			reportComError(e.getMessage());
		}
	}

	public int getConnectionStatus() {
		return mConnectionStatus.get();
	}

	public void sendMavPacket(OPLinkPacket packet) {
		if (!mPacketsToSend.offer(packet)) {
		}
	}

	/**
	 * Adds a listener to the mavlink connection.
	 * 
	 * @param listener
	 * @param tag
	 *            Listener tag
	 */
	public void addOpLinkConnectionListener(String tag, OPLinkConnectionListener listener) {
		mListeners.put(tag, listener);

		if (getConnectionStatus() == OPLINK_CONNECTED) {
			listener.onConnect();
		}
	}

	/**
	 * Removes the specified listener.
	 * 
	 * @param tag
	 *            Listener tag
	 */
	public void removeOpLinkConnectionListener(String tag) {
		mListeners.remove(tag);
	}

	protected abstract void openConnection() throws IOException;

	protected abstract int readDataBlock(byte[] buffer) throws IOException;

	protected abstract void sendBuffer(byte[] buffer) throws IOException;

	protected abstract void closeConnection() throws IOException;

	protected abstract void loadPreferences();

	protected abstract File getTempTLogFile();

	protected abstract void commitTempTLogFile(File tlogFile);

	/**
	 * @return The type of this mavlink connection.
	 */
	public abstract int getConnectionType();

	/**
	 * Overrides if interested in being notified when the log is written. Note:
	 * Is called from a background thred.
	 * 
	 * @param packet
	 *            OPLinkPacket saved to log.
	 */
	protected void onLogSaved(OPLinkPacket packet) throws IOException {
	}

	/**
	 * Queue a mavlink packet for logging.
	 * 
	 * @param packet
	 *            OPLinkPacket packet
	 * @return true if the packet was queued successfully.
	 */
	private boolean queueToLog(OPLinkPacket packet) {
		return mPacketsToLog.offer(packet);
	}

	/**
	 * Utility method to notify the mavlink listeners about communication
	 * errors.
	 * 
	 * @param errMsg
	 */
	private void reportComError(String errMsg) {
		if (mListeners.isEmpty())
			return;

		for (OPLinkConnectionListener listener : mListeners.values()) {
			listener.onComError(errMsg);
		}
	}

	/**
	 * Utility method to notify the mavlink listeners about a successful
	 * connection.
	 */
	private void reportConnect() {
		for (OPLinkConnectionListener listener : mListeners.values()) {
			listener.onConnect();
		}
	}

	/**
	 * Utility method to notify the mavlink listeners about a connection
	 * disconnect.
	 */
	private void reportDisconnect() {
		if (mListeners.isEmpty())
			return;

		for (OPLinkConnectionListener listener : mListeners.values()) {
			listener.onDisconnect();
		}
	}

	/**
	 * Utility method to notify the mavlink listeners about received messages.
	 * 
	 * @param msg
	 *            received mavlink message
	 */
	private void reportReceivedMessage(OPLinkMessage msg) {
		if (mListeners.isEmpty())
			return;

		for (OPLinkConnectionListener listener : mListeners.values()) {
			listener.onReceiveMessage(msg);
		}
	}

}
