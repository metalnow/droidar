package communication.connection;

/**
 * List the supported mavlink connection types.
 */
public class OPLinkConnectionTypes {

	/**
	 * Bluetooth mavlink connection.
	 */
	public static final int OPLINK_CONNECTION_BLUETOOTH = 0;

	/**
	 * USP mavlink connection.
	 */
	public static final int OPLINK_CONNECTION_USB = 1;

	/**
	 * UDP mavlink connection.
	 */
	public static final int OPLINK_CONNECTION_UDP = 2;

	/**
	 * TCP mavlink connection.
	 */
	public static final int OPLINK_CONNECTION_TCP = 3;

	// Not instantiable
	private OPLinkConnectionTypes() {
	}
}
